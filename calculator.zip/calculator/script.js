let input = document.getElementById("input");
let result = document.getElementById("result");
let lastAns = "";

function append(value) {
  if (value === '√') {
    input.value += "Math.sqrt(";
  } else {
    input.value += value;
  }
}

function clearAll() {
  input.value = "";
  result.innerText = "0";
}

function del() {
  input.value = input.value.slice(0, -1);
}

function calculate() {
  try {
    let expression = input.value.replace(/x/g, '*').replace(/÷/g, '/');
    let evalResult = eval(expression);
    result.innerText = evalResult;
    lastAns = evalResult;
  } catch (err) {
    result.innerText = "Error";
  }
}

function answer() {
  input.value += lastAns;
}

function toggleSign() {
  if (input.value.startsWith('-')) {
    input.value = input.value.slice(1);
  } else {
    input.value = '-' + input.value;
  }
}
