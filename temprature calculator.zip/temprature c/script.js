function convertTemp() {
  const degrees = parseFloat(document.getElementById("degrees").value);
  const type = document.getElementById("type").value;
  const resultDiv = document.getElementById("result");

  if (isNaN(degrees)) {
    resultDiv.textContent = "Please enter a valid number!";
    return;
  }

  let result = "";

  switch (type) {
    case "celsius":
      result += `${(degrees * 9/5 + 32).toFixed(4)} °F | `;
      result += `${(degrees + 273.15).toFixed(4)} K`;
      break;
    case "fahrenheit":
      result += `${((degrees - 32) * 5/9).toFixed(4)} °C | `;
      result += `${(((degrees - 32) * 5/9) + 273.15).toFixed(4)} K`;
      break;
    case "kelvin":
      result += `${(degrees - 273.15).toFixed(4)} °C | `;
      result += `${((degrees - 273.15) * 9/5 + 32).toFixed(4)} °F`;
      break;
  }

  resultDiv.textContent = result;
}
